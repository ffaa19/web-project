<?php
// If the user is already logged in, redirect them to the dashboard
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do & Notes Manager - Welcome</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Welcome to To-Do & Notes Manager</h1>
    </header>
    
    <main>
        <div class="container two-column">
            <div class="left">
                <div class="main-content">
                    <div class="intro">
                        <h2>Manage Your Tasks & Notes</h2>
                        <h3>Stay organized and productive</h3>
                        <p>Our easy-to-use system helps you manage your tasks and notes efficiently. Keep track of what needs to be done, add quick notes, and never miss a deadline again.</p>
                        <p>Create your personal account, log in, add tasks or notes, mark tasks as completed, edit or delete them, and sync all your data into a secure database.</p>
                    </div>
                    <div class="buttons">
                        <a href="login.php" class="btn login" aria-label="Go to login page">Login</a>
                        <a href="register.php" class="btn register" aria-label="Go to registration page">Register</a>
                    </div>
                </div>
            </div>
            <div class="right" role="img" aria-label="To-do list illustration">
                <img src="to-do.jpeg" alt="To-do list illustration showing task management" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
        </div>
    </main>
    
    <footer>
        <p>&copy; <?php echo date('Y'); ?> To-Do & Notes Manager. All rights reserved.</p>
    </footer>
</body>
</html>
