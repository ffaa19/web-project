<?php
include 'database.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Move to history
    $stmt = $conn->prepare("INSERT INTO task_history (task, due_date, status) 
                          SELECT task, due_date, 'completed' FROM tasks WHERE id=?");
    $stmt->execute([$id]);

    // Update task status
    $stmt = $conn->prepare("UPDATE tasks SET status='completed' WHERE id=?");
    $stmt->execute([$id]);
}
?>

