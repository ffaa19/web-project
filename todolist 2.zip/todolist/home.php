<?php
// If the user is already logged in, redirect them to the To-Do List page
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: todolist.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to To-Do List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <h1>Welcome to Your To-Do List!</h1>
    </header>
    
    <div class="container two-column">
        <div class="left">
            <div class="main-content">
                <div class="intro">
                    <h2>Manage Your Tasks</h2>
                    <h3>Stay organized and productive</h3>
                    <p>Our easy-to-use system helps you manage your tasks efficiently. Keep track of what needs to be done, set due dates, and never miss a deadline again.</p>
                </div>
                <div class="buttons">
                    <a href="login.php" class="btn login">Login</a>
                    <a href="register.php" class="btn register">Register</a>
                </div>
            </div>
        </div>
        <div class="right"></div>
    </div>
    
    <footer class="footer">
        <p>&copy; <?php echo date('Y'); ?> To-Do List Application. All rights reserved.</p>
    </footer>
</body>
</html>
