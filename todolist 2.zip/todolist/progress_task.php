<?php
include 'database.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $conn->prepare("UPDATE tasks SET status='in progress' WHERE id=?");
    $stmt->execute([$id]);
}
?>
