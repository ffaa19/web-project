<?php
include 'database.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Move task to history before deleting
    $stmt = $conn->prepare("INSERT INTO task_history (task, due_date, status) 
                          SELECT task, due_date, 'deleted' FROM tasks WHERE id=?");
    $stmt->execute([$id]);

    // Delete from tasks table
    $stmt = $conn->prepare("DELETE FROM tasks WHERE id=?");
    $stmt->execute([$id]);
}
?>


